INSERT INTO log_processamento (descricaoLogProcessamento,dataLogProcessamento ) values ('Teste log processamento 1','2021-02-15 23:05:02');
INSERT INTO log_processamento (descricaoLogProcessamento,dataLogProcessamento ) values ('Teste log processamento 2','2021-02-16 23:05:02');
